## CVE's Shodan Dorks.

* Big IP shodan Search:- 

`http.title:"BIG-IP&reg;-Redirect" org:Org`

* CVE 2020-3452
 
` http.html_hash:-628873716 
“set-cookie: webvpn;”` 

* CVE CVE-2019-11510

`http.html:/dana-na/`  

* CVE-2020–5902
 
 ```inurl:/tmui/login.jsp```


## Author:
- [@manasH4rsh](https://twitter.com/manasH4rsh)
- [Fani Malik](https://twitter.com/FaniMalikHack)
