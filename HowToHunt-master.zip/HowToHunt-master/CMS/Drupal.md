## Drupal Nodes
 If you hunt on a Drupal website: fuzz with intruder on '/node/$' where '$' is a number (from 1 to 500 for example). 
 You could find hidden pages (test, dev) which are not referenced by the search engines.

* [Credits](https://twitter.com/adrien_jeanneau/status/1273952564430725123?t=SUinUf09jxjRXu1yF9AQDg&s=19)
