# RedTeam

> Get-ControllerList.ps1 

The above PS file will help to get the list of Domain Controller in a network, and will create a csv file in C: drive
This can be used during Network Pentesting or such other situtations.

Reference : https://gallery.technet.microsoft.com/scriptcenter/Get-List-of-Domain-4c993070

> Invoke-Mimikatz.ps1 

This runs Mimikatz PS script by directly pulling it from Github and executing it "in memory" on your system.

Reference : https://gallery.technet.microsoft.com/scriptcenter/Invoke-Mimikatz-and-will-d6c40fac

> HostRecon.ps1

The above Module check and gather information of the local system, users, and domain Information, this can be use durning penesting in post Exploitation part.
