# Some MindMap
---
### OAuth by Hack3rSr0lls
![https://pbs.twimg.com/media/EZ1WqmcXYAAqwSH?format=jpg&name=900x900](https://pbs.twimg.com/media/EZ1WqmcXYAAqwSH?format=jpg&name=900x900)

### Source
* [https://twitter.com/hackerscrolls/status/1269266750467649538](https://twitter.com/hackerscrolls/status/1269266750467649538)

### Author
* [KathanP19](https://twitter.com/KathanP19)
