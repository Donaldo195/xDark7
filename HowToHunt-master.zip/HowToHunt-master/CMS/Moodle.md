## Mass Hunting XSS — Moodle
* [https://dewangpanchal98.medium.com/mass-hunting-xss-moodle-ed4b50c82516](https://dewangpanchal98.medium.com/mass-hunting-xss-moodle-ed4b50c82516)

## Author:
[@th3.d1p4k](https://twitter.com/DipakPanchal05)
