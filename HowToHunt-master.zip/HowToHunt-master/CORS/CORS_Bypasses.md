# CORS Bypass	
1. `Origin:null`
2. `Origin:attacker.com`
3. `Origin:attacker.target.com`
4. `Origin:attackertarget.com`
5. `Origin:sub.attackertarget.com`
6. `Origin:attacker.com and then change the method Get to post/Post to Get`
7. `Origin:sub.attacker target.com`
8. `Origin:sub.attacker%target.com`
9. `Origin:attacker.com/target.com`

### Authors

* [@tamimhasan404](https://twitter.com/tamimhasan404)
	
# Reference Tweets
https://twitter.com/trbughunters/status/1287023673845612546

https://twitter.com/Paresh_parmar1/status/1265251507655630848

https://twitter.com/Alra3ees/status/1141504347089584128
