# Some MindMaps
---
### SSTI Finding Attack Vector by @what_web
![https://pbs.twimg.com/media/EnwZh7qXcAEB3wu?format=jpg&name=large](https://pbs.twimg.com/media/EnwZh7qXcAEB3wu?format=jpg&name=large)

### Source
* [https://twitter.com/jae_hak99/status/1331967876417327104?s=20](https://twitter.com/jae_hak99/status/1331967876417327104?s=20)

### Tools
+ [tplmap](https://github.com/epinna/tplmap)
### Author
* [0xsunil](https://twitter.com/0xsunil)
