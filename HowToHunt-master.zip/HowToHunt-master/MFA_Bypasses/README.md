# Some MindMaps
---
### 2FA Bypass by Hack3rScr0lls
![https://pbs.twimg.com/media/EW8vBWEX0AAxcVj?format=jpg&name=small](https://pbs.twimg.com/media/EW8vBWEX0AAxcVj?format=jpg&name=small)

### Source
* [https://twitter.com/hackerscrolls/status/1256276376019230720](https://twitter.com/hackerscrolls/status/1256276376019230720)

### 2FA Bypass by Harshbothra 
* [MindMap](https://www.mindmeister.com/1736437018?t=SEeZOmvt01)

### Author
* [KathanP19](https://twitter.com/KathanP19)
