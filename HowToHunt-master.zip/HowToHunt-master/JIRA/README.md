
## Blogs
- Jira vulnerabilities and how they are exploited in the wild - [thehackerish Blog](https://thehackerish.com/jira-vulnerabilities-and-how-they-are-exploited-in-the-wild/)


# Tools
- [Jira-Lens](https://github.com/MayankPandey01/Jira-Lens) [Jira-Lens 🔍 is a Python Based vulnerability Scanner for JIRA.This tool Performs 25+ Checks including CVE's and Multiple Disclosures on the Provided JIRA Instance]


# Author
**Name:** Mayank Pandey

**Handle:** [@mayank_pandey01](https://twitter.com/mayank_pandey01)

