# Some MindMap
---
### 6 CSRF Bypass by Hack3rSr0lls
![https://pbs.twimg.com/media/EY70bxkWkAAFzGb?format=jpg&name=900x900](https://pbs.twimg.com/media/EY70bxkWkAAFzGb?format=jpg&name=900x900)

### CSRF Mindmap
![https://gblobscdn.gitbook.com/assets%2F-L_2uGJGU7AVNRcqRvEi%2F-LrAtLpniLVMCWL-CVF-%2F-LrAtNhzv9bhi7vB_zs7%2Fimage.png?alt=media&token=ead94d04-f31d-4d99-9087-9bf92d091b0b](https://gblobscdn.gitbook.com/assets%2F-L_2uGJGU7AVNRcqRvEi%2F-LrAtLpniLVMCWL-CVF-%2F-LrAtNhzv9bhi7vB_zs7%2Fimage.png?alt=media&token=ead94d04-f31d-4d99-9087-9bf92d091b0b)

### Source
* [https://twitter.com/hackerscrolls/status/1265217322308046849](https://twitter.com/hackerscrolls/status/1265217322308046849)

### Author
* [KathanP19](https://twitter.com/KathanP19)
