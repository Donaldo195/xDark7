# Password Reset Mindmap
![https://pbs.twimg.com/media/EhN29bpU8AMvLxx?format=jpg&name=medium](https://pbs.twimg.com/media/EhN29bpU8AMvLxx?format=jpg&name=medium)

# Source
* [Twitter](https://twitter.com/N008x/status/1302515523557548032/photo/1)
* [Blog](https://anugrahsr.github.io/posts/10-Password-reset-flaws/)
# Authors
* [KathanP19](https://twitter.com/KathanP19)
