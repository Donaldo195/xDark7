# Some Mind Maps
--------
### 403 Mindmap
![https://pbs.twimg.com/media/EWmW9-tWkAA4vLs?format=jpg&name=900x900](https://pbs.twimg.com/media/EWmW9-tWkAA4vLs?format=jpg&name=900x900)

### Source 
* [https://twitter.com/hackerscrolls/status/1254701239360720900](https://twitter.com/hackerscrolls/status/1254701239360720900)
---
### Few Twitter Tips
![https://pbs.twimg.com/media/EheFZJvVgAEuzZ1?format=png&name=small](https://pbs.twimg.com/media/EheFZJvVgAEuzZ1?format=png&name=small)
* [https://twitter.com/iam_j0ker/status/1303658167205728256](https://twitter.com/iam_j0ker/status/1303658167205728256)
---
### Few More Twitter Tips
![https://pbs.twimg.com/media/EkezB9QW0AAKa-Y?format=jpg&name=medium](https://pbs.twimg.com/media/EkezB9QW0AAKa-Y?format=jpg&name=medium)
![https://pbs.twimg.com/media/EkezB9VXUAYttBU?format=jpg&name=large](https://pbs.twimg.com/media/EkezB9VXUAYttBU?format=jpg&name=large)
![https://pbs.twimg.com/media/EkezB9LX0AA8DET?format=jpg&name=large](https://pbs.twimg.com/media/EkezB9LX0AA8DET?format=jpg&name=large)
* [https://twitter.com/h4x0r_dz/status/1317218511937261570](https://twitter.com/h4x0r_dz/status/1317218511937261570)
---
### Author
* [KathanP19](https://twitter.com/KathanP19)
